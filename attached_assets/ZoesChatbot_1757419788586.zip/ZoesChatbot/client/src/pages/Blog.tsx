import { useState } from "react";

interface BlogPost {
  id: number;
  title: string;
  content: string;
  image?: string;
  date: string;
  excerpt: string;
}

// Sample blog posts - you can replace these with your own content
const samplePosts: BlogPost[] = [
  {
    id: 1,
    title: "Wie KI deinen Arbeitsalltag revolutioniert",
    content: `
      <h2>Die Zukunft der Arbeit ist bereits da</h2>
      <p>Künstliche Intelligenz verändert nicht nur große Unternehmen, sondern auch den Alltag von Solopreneuren und kleinen Teams. In diesem Artikel zeige ich dir, wie du KI-Tools erfolgreich in deinen Workflow integrieren kannst.</p>
      
      <h3>Die wichtigsten KI-Tools für den Einstieg</h3>
      <ul>
        <li><strong>ChatGPT:</strong> Für Texterstellung und Brainstorming</li>
        <li><strong>Midjourney:</strong> Für kreative Bildgenerierung</li>
        <li><strong>Notion AI:</strong> Für Dokumentation und Organisation</li>
      </ul>
      
      <p>Der Schlüssel liegt nicht darin, alle Tools zu verwenden, sondern die richtigen für deine spezifischen Bedürfnisse zu finden.</p>
    `,
    excerpt: "Entdecke, wie KI-Tools deinen Arbeitsalltag effizienter machen können - ohne komplizierte Technik.",
    date: "2024-12-28",
    image: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=800&h=400&fit=crop"
  },
  {
    id: 2,
    title: "Chatbots für kleine Unternehmen",
    content: `
      <h2>Warum jedes kleine Unternehmen einen Chatbot braucht</h2>
      <p>Chatbots sind nicht nur für große Konzerne da. Auch kleine Unternehmen können enorm von automatisierten Kundenservice-Lösungen profitieren.</p>
      
      <h3>Die Vorteile auf einen Blick</h3>
      <ul>
        <li>24/7 Kundenbetreuung</li>
        <li>Automatische Beantwortung häufiger Fragen</li>
        <li>Lead-Generierung im Schlaf</li>
        <li>Kostenersparnis bei der Kundenbetreuung</li>
      </ul>
      
      <p>Ein gut konfigurierter Chatbot kann bis zu 80% der Standardanfragen automatisch beantworten.</p>
    `,
    excerpt: "Warum Chatbots auch für kleine Unternehmen eine lohnende Investition sind.",
    date: "2024-12-25",
    image: "https://images.unsplash.com/photo-1531746790731-6c087fecd65a?w=800&h=400&fit=crop"
  },
  {
    id: 3,
    title: "Automation ohne Programmierkenntnisse",
    content: `
      <h2>No-Code Automation für Einsteiger</h2>
      <p>Du musst kein Programmierer sein, um deine Arbeitsabläufe zu automatisieren. Moderne No-Code-Tools machen es möglich.</p>
      
      <h3>Meine Top-Empfehlungen</h3>
      <ul>
        <li><strong>Zapier:</strong> Verbindet verschiedene Apps miteinander</li>
        <li><strong>Make (ehemals Integromat):</strong> Für komplexere Workflows</li>
        <li><strong>n8n:</strong> Open-Source Alternative mit mehr Kontrolle</li>
      </ul>
      
      <p>Starte klein und automatisiere nach und nach mehr Prozesse. So behältst du die Kontrolle und lernst kontinuierlich dazu.</p>
    `,
    excerpt: "Lerne, wie du ohne Programmierkenntnisse deine ersten Automatisierungen erstellst.",
    date: "2024-12-20",
    image: "https://images.unsplash.com/photo-1518186285589-2f7649de83e0?w=800&h=400&fit=crop"
  }
];

export default function Blog() {
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);

  if (selectedPost) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#2c1810] via-[#3d251a] to-[#4a2c1a] text-[#f5f5f5]">
        <div className="container mx-auto px-6 py-32">
          <button
            onClick={() => setSelectedPost(null)}
            className="mb-8 bg-[#d4af37]/20 hover:bg-[#d4af37]/30 text-[#d4af37] px-6 py-2 rounded-full border border-[#d4af37]/30 transition-all"
          >
            ← Zurück zur Übersicht
          </button>
          
          <article className="max-w-4xl mx-auto">
            {selectedPost.image && (
              <img
                src={selectedPost.image}
                alt={selectedPost.title}
                className="w-full h-64 md:h-96 object-cover rounded-2xl mb-8 shadow-xl"
              />
            )}
            
            <header className="mb-8">
              <h1 className="text-4xl md:text-5xl font-heading font-bold mb-4 text-[#f4d03f]">
                {selectedPost.title}
              </h1>
              <time className="text-[#d4af37] text-lg">
                {new Date(selectedPost.date).toLocaleDateString('de-DE', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}
              </time>
            </header>
            
            <div 
              className="prose prose-lg prose-invert max-w-none"
              dangerouslySetInnerHTML={{ __html: selectedPost.content }}
              style={{
                '--tw-prose-body': '#f5f5f5',
                '--tw-prose-headings': '#f4d03f',
                '--tw-prose-links': '#d4af37',
                '--tw-prose-strong': '#f4d03f',
                '--tw-prose-bullets': '#d4af37'
              } as any}
            />
          </article>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#2c1810] via-[#3d251a] to-[#4a2c1a] text-[#f5f5f5]">
      <div className="container mx-auto px-6 py-32">
        <header className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-heading font-bold mb-6 text-[#f4d03f]">
            KI-Insights & Praxis-Tipps
          </h1>
          <p className="text-xl md:text-2xl opacity-90 max-w-3xl mx-auto">
            Praktische Einblicke in die Welt der KI, Automation und digitalen Transformation - 
            speziell für Solopreneure und kleine Teams.
          </p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {samplePosts.map((post) => (
            <article
              key={post.id}
              className="bg-[#d4af37]/10 backdrop-blur-md rounded-2xl border border-[#d4af37]/20 overflow-hidden hover:bg-[#d4af37]/15 transition-all cursor-pointer group"
              onClick={() => setSelectedPost(post)}
            >
              {post.image && (
                <img
                  src={post.image}
                  alt={post.title}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                />
              )}
              
              <div className="p-6">
                <time className="text-[#d4af37] text-sm mb-2 block">
                  {new Date(post.date).toLocaleDateString('de-DE', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                </time>
                
                <h2 className="text-xl font-heading font-bold mb-3 text-[#f4d03f] group-hover:text-[#f4d03f] transition-colors">
                  {post.title}
                </h2>
                
                <p className="opacity-90 leading-relaxed">
                  {post.excerpt}
                </p>
                
                <div className="mt-4 text-[#d4af37] group-hover:text-[#f4d03f] transition-colors">
                  Weiterlesen →
                </div>
              </div>
            </article>
          ))}
        </div>

        <div className="text-center mt-16">
          <div className="bg-[#d4af37]/10 backdrop-blur-md rounded-2xl p-8 border border-[#d4af37]/20 max-w-2xl mx-auto">
            <h3 className="text-2xl font-heading font-bold mb-4 text-[#f4d03f]">
              Möchtest du mehr erfahren?
            </h3>
            <p className="mb-6 opacity-90">
              Abonniere meinen Newsletter für regelmäßige KI-Tipps und exklusive Insights.
            </p>
            <button
              onClick={() => {
                const element = document.getElementById("contact");
                if (element) {
                  const offset = 80;
                  const elementPosition = element.getBoundingClientRect().top;
                  const offsetPosition = elementPosition + window.pageYOffset - offset;
                  window.scrollTo({
                    top: offsetPosition,
                    behavior: "smooth",
                  });
                }
              }}
              className="bg-gradient-to-r from-[#d4af37] to-[#f4d03f] text-[#2c1810] px-8 py-3 rounded-full font-heading font-bold hover:shadow-lg hover:shadow-[#d4af37]/30 transition-all"
            >
              Kontakt aufnehmen
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}