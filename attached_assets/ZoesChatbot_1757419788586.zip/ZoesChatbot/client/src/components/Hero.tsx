import WaveShape from "./WaveShape";

export default function Hero() {
  return (
    <section className="pt-32 pb-20 md:pt-40 md:pb-32 px-6 relative bg-gradient-to-br from-[#2c1810] via-[#3d251a] to-[#4a2c1a] text-[#f5f5f5] overflow-hidden">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="z-10">
            <h1 className="text-4xl md:text-5xl font-heading font-bold leading-tight mb-4">
              Willkommen bei Zoë's KI Toolbox
            </h1>
            <h2 className="text-2xl md:text-3xl font-heading opacity-90 mb-4">
              Clever. Charmant. Chatbot.
            </h2>
              <p className="text-lg md:text-xl opacity-90 mb-2">
                KI mit Herz & Hirn
              </p>
              <p className="text-lg md:text-xl opacity-90 mb-8">
              Hey du! Schön, dass du da bist. 
                  
              Zoe´s KI-Toolbox – Beratung für clevere KI-Lösungen mit Persönlichkeit. Ich baue maßgeschneiderte Chatbots und Auomationen, die dein Team entlasten, deine Kunden begeistern und dir Zeit sparen – ganz ohne Hokuspokus.


              
              
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={() => {
                  const element = document.getElementById("contact");
                  if (element) {
                    const offset = 80;
                    const elementPosition = element.getBoundingClientRect().top;
                    const offsetPosition =
                      elementPosition + window.pageYOffset - offset;

                    window.scrollTo({
                      top: offsetPosition,
                      behavior: "smooth",
                    });
                  }
                }}
                className="bg-gradient-to-r from-[#d4af37] to-[#f4d03f] text-[#2c1810] py-3 px-8 rounded-full font-heading font-bold shadow-lg shadow-[#d4af37]/30 hover:shadow-xl hover:shadow-[#d4af37]/40 hover:-translate-y-1 transition-all duration-300 inline-flex items-center justify-center"
              >
                Kontakt aufnehmen →
              </button>
              <button
                onClick={() => {
                  const element = document.getElementById("how-it-works");
                  if (element) {
                    const offset = 80;
                    const elementPosition = element.getBoundingClientRect().top;
                    const offsetPosition =
                      elementPosition + window.pageYOffset - offset;

                    window.scrollTo({
                      top: offsetPosition,
                      behavior: "smooth",
                    });
                  }
                }}
                className="bg-[#d4af37]/20 backdrop-blur-sm text-[#f5f5f5] py-3 px-8 rounded-full font-heading font-bold inline-block text-center hover:bg-[#d4af37]/30 border border-[#d4af37]/20 hover:border-[#d4af37]/40 transition-all"
              >
                Mehr erfahren
              </button>
            </div>
          </div>
          <div className="relative z-10">
            <div className="bg-[#d4af37]/10 backdrop-blur-md rounded-2xl shadow-xl p-6 border border-[#d4af37]/20">
              <h3 className="font-heading font-bold text-2xl mb-4">
                Ich biete Dir:
              </h3>
              <ul className="space-y-3">
                <li className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-[#d4af37] mr-3"></div>
                  <span>
                    Schulungen & Workshops:
                    Wie spare ich mit KI konkret Zeit und Nerven?

                  
                  </span>
                </li>
                <li className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-[#d4af37] mr-3"></div>
                  <span>Flexible KI‑Modelle: Ob ChatGPT, eigene KI oder Hybrid – wir finden gemeinsam genau deine Lösung. </span>
                </li>
                <li className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-[#d4af37] mr-3"></div>
                  <span>
                    Automatisierte intelligente Workflows: Reduziere deine Routine-Jobs- von E-Mails bis Kundenservice läuft alles automatisch. Auf Wunsch mit Lead-Generierung.

                    
                  </span>
                </li>
              </ul>
              <div className="mt-6 pt-4 border-t border-white/20">
                <p className="font-medium">
                  Sag mir, was du brauchst – wir bauen's leicht & schön
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Decorative elements */}
      <div className="absolute top-20 right-10 w-20 h-20 rounded-full bg-[#d4af37]/15 animate-bounce duration-[3000ms]"></div>
      <div className="absolute bottom-40 left-10 w-12 h-12 rounded-full bg-[#d4af37]/15 animate-bounce duration-[3000ms] delay-1000"></div>
      <div className="absolute top-40 left-20 w-8 h-8 rounded-full bg-[#d4af37]/15 animate-bounce duration-[3000ms] delay-500"></div>

      {/* Wave divider */}
      <WaveShape />
    </section>
  );
}
