# replit.md

## Overview

This is a full-stack web application for an AI consulting business called "Zoë's KI Toolbox" (Zoë's AI Toolbox). The application showcases AI chatbot services and provides a platform for potential clients to learn about and interact with AI-powered solutions. It's built with a modern tech stack including React/TypeScript frontend, Express.js backend, and PostgreSQL database with Drizzle ORM.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **UI Components**: Radix UI primitives with shadcn/ui components
- **Styling**: Tailwind CSS with custom theming
- **Icons**: Font Awesome icons
- **State Management**: TanStack Query for server state management
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ESM modules
- **API**: RESTful API design
- **Development**: tsx for TypeScript execution in development

### Database Architecture
- **Database**: PostgreSQL
- **ORM**: Drizzle ORM with Drizzle Kit for migrations
- **Connection**: Neon Database serverless connection
- **Schema**: Strongly typed schema definitions in TypeScript

## Key Components

### Database Schema
The application uses three main database tables:
- **users**: User authentication with username/password
- **messages**: Chat message storage with session tracking
- **contactForms**: Contact form submissions with processing status

### API Endpoints
- **Health Check**: `/api/health` - Server status endpoint
- **Chat**: `/api/chat` - Chatbot message handling with session management
- **Contact**: `/api/contact` - Contact form submission handling

### Frontend Pages
- **Home**: Main landing page with hero, features, testimonials, and contact sections
- **Blog**: Content management page with sample blog posts about AI and automation
- **ChatbotPage**: Dedicated chatbot interaction page
- **ChatbotDemo1**: FAQ bot demonstration
- **ChatbotDemo2**: Customer service bot demonstration

### External Integrations
- **n8n Chat Widget**: Integrated floating chat widget for live AI assistance
- **Replit Deployment**: Configured for Replit's cloud platform

## Data Flow

1. **User Interaction**: Users interact with the website through the React frontend
2. **API Communication**: Frontend communicates with Express.js backend via REST API
3. **Database Operations**: Backend uses Drizzle ORM to interact with PostgreSQL database
4. **Chat Functionality**: Chat messages are stored with session IDs and bot responses are generated server-side
5. **Contact Forms**: Form submissions are stored in database for processing
6. **External Chat**: n8n chat widget provides additional AI assistance independent of the main application

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL connection for serverless environments
- **@tanstack/react-query**: Server state management and caching
- **@radix-ui/***: Accessible UI component primitives
- **@n8n/chat**: Third-party chat widget integration
- **drizzle-orm**: Type-safe database ORM
- **wouter**: Lightweight React router

### Development Dependencies
- **tsx**: TypeScript execution for development
- **esbuild**: Fast JavaScript bundler for production builds
- **vite**: Development server and build tool
- **@replit/vite-plugin-***: Replit-specific development plugins

## Deployment Strategy

### Development Environment
- **Command**: `npm run dev` - Runs tsx server with hot reloading
- **Port**: 5000 (mapped to external port 80)
- **Database**: Uses DATABASE_URL environment variable

### Production Build
- **Frontend Build**: `vite build` - Compiles React app to static files
- **Backend Build**: `esbuild` - Bundles server code to single file
- **Start Command**: `npm start` - Runs production server

### Platform Configuration
- **Platform**: Replit with autoscale deployment
- **Modules**: Node.js 20, Web, PostgreSQL 16
- **Environment**: Configured for Replit's infrastructure

## Changelog

```
Changelog:
- June 27, 2025. Updated color scheme to dark brown/gold theme, added blog page with content management
- June 25, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```