
export default function ChatWidget() {
  return <div id="n8n-chat" />;
}
